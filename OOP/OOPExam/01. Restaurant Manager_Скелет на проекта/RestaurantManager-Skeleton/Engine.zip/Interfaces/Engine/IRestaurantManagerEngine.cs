﻿namespace RestaurantManager.Interfaces.Engine
{
    public interface IRestaurantManagerEngine
    {
        void Start();
    }
}
