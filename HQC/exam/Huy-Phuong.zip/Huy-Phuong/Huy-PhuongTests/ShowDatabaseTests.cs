﻿using Huy_Phuong;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Huy_Phuong.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Huy_Phuong;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// The show database tests.
    /// </summary>
    [TestClass()]
    public class ShowDatabaseTests
    {
        /// <summary>
        /// The add performance test.
        /// </summary>
        [TestMethod()]
        public void AddPerformanceTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void AddPerformanceTest1()
        {

        }
    }
}
