﻿namespace MyTunesShop
{
    using System;

    public interface IMedia
    {
        string Title { get; }

        decimal Price { get; }
    }
}
