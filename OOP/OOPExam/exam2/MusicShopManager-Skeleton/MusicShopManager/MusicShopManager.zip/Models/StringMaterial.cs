﻿namespace MusicShopManager.Models
{
    using System;

    public enum StringMaterial
    {
        Steel,
        Brass,
        Bronze,
        Nylon
    }
}
